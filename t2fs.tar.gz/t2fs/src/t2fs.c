#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../include/t2fs.h"
#include "../include/apidisk.h"
#include "../include/bitmap2.h"


#define MAX_FILES 20
#define MFT_ENTRY_SIZE 512
#define SECTORS_PER_MFT_ENTRY 2
#define TUPLES_PER_MFT_ENTRY 32
#define TUPLES_PER_SECTOR 16
#define FALSE 0
#define TRUE 1
#define DEBUG FALSE
#define RECORD_SIZE 64
#define DIRECTORY_ENTRIES_PER_SECTOR SECTOR_SIZE/RECORD_SIZE //4

/*
#define TYPEVAL_INVALIDO    0x00
#define TYPEVAL_REGULAR     0x01
#define TYPEVAL_DIRETORIO   0x02
*/
#define TYPEVAL_INVALID TYPEVAL_INVALIDO
#define TYPEVAL_DIRECTORY TYPEVAL_DIRETORIO


typedef struct t2fs_record t2fs_record;
typedef struct t2fs_bootBlock t2fs_bootBlock;
typedef struct t2fs_4tupla t2fs_4tupla;

typedef struct t2fs_bootBlock BOOT_PARTITION;
typedef struct {
	struct t2fs_4tupla tuplas[TUPLES_PER_MFT_ENTRY];
} t2fs_MFT;

typedef struct{
	t2fs_record fileDescriptor;
	t2fs_4tupla fileControlBlock[TUPLES_PER_MFT_ENTRY];
	unsigned int current_pointer;
	BYTE *data; //[SECTOR_SIZE*systemInfo.MFTBlocksSize]
}openFileEntry;

typedef int bool;

bool initialized = FALSE;

const char slash[2] = {'\'', '\0'};

openFileEntry openFileTable[MAX_FILES];
bool fileIsOpen[MAX_FILES];
t2fs_4tupla currentDirMFT[TUPLES_PER_MFT_ENTRY];
t2fs_record currentDirDescriptor;
t2fs_4tupla prevDirMFT[TUPLES_PER_MFT_ENTRY];
t2fs_record prevDirDescriptor;
t2fs_record currentFileDescriptor;

BOOT_PARTITION systemInfo;

t2fs_4tupla rootMFT[TUPLES_PER_MFT_ENTRY];
t2fs_record rootDescriptor;

DWORD FIRST_MFT_SECTOR;
DWORD FIRST_DATA_SECTOR;
int MFT_ENTRIES_PER_BLOCK;

WORD BLOCK_SIZE;
int currentBlockNumber;

void printBootPartition() {		

	printf("Boot ID:%.4s, version:%d, blockSize:%d, MFTBlockSize:%d, diskSectorSize:%d\n", 
	systemInfo.id, systemInfo.version, systemInfo.blockSize, systemInfo.MFTBlocksSize, systemInfo.diskSectorSize);
}

void initializeSystem(){
	int i;
	BYTE buffer[SECTOR_SIZE];
	if(read_sector(0, buffer))
		printf("ERROR: Could not read boot partition.\n");

	memcpy(&systemInfo, buffer, sizeof(BOOT_PARTITION));

	if (DEBUG){
		printBootPartition();
	}

	BLOCK_SIZE = systemInfo.blockSize;

	for (i = 0; i < MAX_FILES; i++){
		fileIsOpen[i] = FALSE;
	}

	FIRST_MFT_SECTOR = BLOCK_SIZE * SECTOR_SIZE;
	// FIRST DATA SECTOR = BOOT SIZE (1 block) + MFTBLOCKSNUMBER blocks
	FIRST_DATA_SECTOR = (1 * BLOCK_SIZE) + (systemInfo.MFTBlocksSize * BLOCK_SIZE);
	MFT_ENTRIES_PER_BLOCK = BLOCK_SIZE/SECTORS_PER_MFT_ENTRY;

	for (i = 0; i < SECTORS_PER_MFT_ENTRY; i++){
		if (read_sector(((FIRST_MFT_SECTOR+SECTORS_PER_MFT_ENTRY)+(i*SECTORS_PER_MFT_ENTRY)), buffer))
			printf("ERROR: Could not read root MFT.\n");

		memcpy(rootMFT+(i*TUPLES_PER_SECTOR), buffer, SECTOR_SIZE);
	}
	

	//If you want to read MFT entry index i
	//You need to read SECTORS_PER_MFT_ENTRY sectors starting from
	//FIRST_MFT_SECTOR + (i*SECTORS_PER_MFT_ENTRY);

	initialized = TRUE;
}

void setRootAsCurrentDirectory(){
	memcpy(&currentDirDescriptor, &rootDescriptor, RECORD_SIZE);
	memcpy(currentDirMFT, rootMFT, (TUPLES_PER_MFT_ENTRY*sizeof(t2fs_4tupla)));
}

t2fs_MFT readT2FS_MFT_on_sector(int sector) {

	unsigned char buffer1[2*SECTOR_SIZE];
	unsigned char buffer2[SECTOR_SIZE];

	t2fs_MFT mft;
	if(read_sector(sector, buffer1)!=0 && DEBUG) printf("Error reading sector t2fs\n");
	if(read_sector(sector+1, buffer2)!=0 && DEBUG) printf("Error reading sectort2fs\n");
	
	memcpy(buffer1+SECTOR_SIZE, buffer2, SECTOR_SIZE);
	memcpy(&mft, buffer1, 2*SECTOR_SIZE);

	return mft;
}


void writeT2FS_MFT_on_sector(int sector, t2fs_MFT mft) {

    if(sector==0) {
        printf("Tentando escrever T2FS_MFT no BOOT\n");
        return;
    }
	unsigned char buffer[2*SECTOR_SIZE];
	memcpy(buffer, &mft, 2*SECTOR_SIZE);

	unsigned char buffer1[SECTOR_SIZE];	
	unsigned char buffer2[SECTOR_SIZE];

	memcpy(buffer1, buffer, SECTOR_SIZE);
	memcpy(buffer2, buffer+SECTOR_SIZE, SECTOR_SIZE);

	if(write_sector(sector, buffer1)!=0 && DEBUG) printf("Error writing sector mft1X\n");		
	if(write_sector(sector+1, buffer2)!=0 && DEBUG) printf("Error writing sector mft2\n");		
}

int searchFreeMFTSector() {

	t2fs_MFT mft;
	int i;
	for(i=FIRST_MFT_SECTOR; i<=FIRST_MFT_SECTOR+(systemInfo.MFTBlocksSize*BLOCK_SIZE); i+=SECTORS_PER_MFT_ENTRY) {

		//procura um arquivo
		mft = readT2FS_MFT_on_sector(i);
		if(mft.tuplas[0].atributeType == -1) {
			return i;
		}
	}
	return -1;
}

int findFromCurrent(char *name, BYTE typeV){
	bool found = FALSE;
	bool searchedEveryEntry = FALSE;
	bool searchedEveryBlock = FALSE;
	bool searchedEveryRecord = FALSE;
	int nextMFTRegister;
	int i;
	int nextEntryMFT;
	int nextBlock;
	int nextRecord;
	int currentDirEntries;
	int foundEntries;
	int currentBlockNum;
	t2fs_record	currentBlock[DIRECTORY_ENTRIES_PER_SECTOR*BLOCK_SIZE];
	BYTE buffer[SECTOR_SIZE];

	if ((currentDirDescriptor.bytesFileSize % RECORD_SIZE) != 0){
		if (DEBUG){
			printf("Current directory has incorrect number of bytes\n");
		}
		return -1;
	}
	currentDirEntries = currentDirDescriptor.bytesFileSize/RECORD_SIZE;
	foundEntries = 0;
	nextEntryMFT = 0;
	nextRecord = 0;

	/*

	1	for each entry in MFT
	2		for each block pointed by entry
	3			for each record in block
	4				if record.name = next_dir && record.type = directory
	5					current_dir_descriptor = record
	6					current_dir_mft = record.mft

	*/

	while (!found && !searchedEveryEntry){
		//load new mft entry
		nextBlock = 0;
		while (!found && !searchedEveryBlock && !searchedEveryEntry){
			//load new block
			if (currentDirMFT[nextEntryMFT].atributeType != 1){
				if (DEBUG){
					printf("Current entry on MFT is not a VBN-LBN mapping entry\n");
				}
				return -1;
			}


			for (i = 0; i < BLOCK_SIZE; i++){
				//???????????
				if (read_sector(currentDirMFT[nextEntryMFT].logicalBlockNumber+(BLOCK_SIZE*nextBlock)+i, buffer) && DEBUG){
					printf("ERROR: Could not read MFT for %s.\n", name);
					return -1;
				}
				currentBlockNum = currentDirMFT[nextEntryMFT].logicalBlockNumber+(BLOCK_SIZE*nextBlock);
				memcpy(currentBlock+(i*DIRECTORY_ENTRIES_PER_SECTOR), buffer, SECTOR_SIZE);
			}

			
			while (!found && !searchedEveryRecord && !searchedEveryEntry){
				if ((currentBlock[nextRecord].TypeVal == TYPEVAL_DIRECTORY) || (currentBlock[nextRecord].TypeVal == TYPEVAL_REGULAR)){
					foundEntries++;
					if (foundEntries >= currentDirEntries && typeV != TYPEVAL_INVALID){
						searchedEveryEntry = TRUE;
					}
				}
				if (currentBlock[nextRecord].TypeVal == typeV){
					if ((typeV == TYPEVAL_DIRECTORY || typeV == TYPEVAL_REGULAR) && (strcmp(currentBlock[nextRecord].name, name) == 0)){
						return currentBlockNum;
					}else{
						if (typeV == TYPEVAL_INVALID){
							return currentBlockNum;
						}
					}
				}
				nextRecord++;
				if (nextRecord >= DIRECTORY_ENTRIES_PER_SECTOR){
					nextRecord = 0;
					searchedEveryRecord = TRUE;
				}
			}
			
			nextBlock++;
			if (nextBlock >= currentDirMFT[nextEntryMFT].numberOfContiguosBlocks){
				searchedEveryBlock = TRUE;
				nextBlock = 0;
			}
		}
		
		nextEntryMFT++;
		if (nextEntryMFT >= TUPLES_PER_MFT_ENTRY-1){
			if (currentDirMFT[TUPLES_PER_MFT_ENTRY-1].atributeType != 2){
				if (DEBUG){
					printf("Last tuple of MFT is not a chain link\n");
				}
				return -1;
			}

			nextMFTRegister = currentDirMFT[TUPLES_PER_MFT_ENTRY-1].virtualBlockNumber;
			for (i = 0; i < SECTORS_PER_MFT_ENTRY; i++){
				if (read_sector(((FIRST_MFT_SECTOR+(SECTORS_PER_MFT_ENTRY*nextMFTRegister))+(i*SECTORS_PER_MFT_ENTRY)), buffer) && DEBUG){
					printf("ERROR: Could not read MFT for %s.\n", name);
				}

				memcpy(currentDirMFT+(i*TUPLES_PER_SECTOR), buffer, SECTOR_SIZE);
			}

			nextEntryMFT = 0;
		}
	}

	if (!found){
		if (DEBUG){
			printf("Could not find directory %s in current directory\n", name);
		}
		return -1;
	}

	return 0;
}

int openFromCurrent(char *name, BYTE typeV, int block){
	t2fs_record	currentBlock[DIRECTORY_ENTRIES_PER_SECTOR*BLOCK_SIZE];
	BYTE buffer[SECTOR_SIZE];
	int nextRecord;
	int i;

	for (i = 0; i < BLOCK_SIZE; i++){
		//???????????
		if (read_sector(block+i, buffer) && DEBUG){
			printf("ERROR: Could not read MFT for %s.\n", name);
		}
		memcpy(currentBlock+(i*DIRECTORY_ENTRIES_PER_SECTOR), buffer, SECTOR_SIZE);
	}

	for (nextRecord = 0; nextRecord < DIRECTORY_ENTRIES_PER_SECTOR*BLOCK_SIZE; nextRecord++){

		if (currentBlock[nextRecord].TypeVal == typeV){
			if (typeV == TYPEVAL_DIRECTORY && (strcmp(currentBlock[nextRecord].name, name) == 0)){
				memcpy(&prevDirDescriptor, &currentDirDescriptor, RECORD_SIZE);
				memcpy(&currentDirDescriptor,currentBlock+nextRecord,RECORD_SIZE);
				break;

				for (i = 0; i < SECTORS_PER_MFT_ENTRY; i++){
					if (read_sector(((FIRST_MFT_SECTOR+(SECTORS_PER_MFT_ENTRY*currentDirDescriptor.MFTNumber))+(i*SECTORS_PER_MFT_ENTRY)), buffer) && DEBUG){
						printf("ERROR: Could not read MFT for %s.\n", name);
						return -1;
					}
					memcpy(prevDirMFT+(i*TUPLES_PER_SECTOR), currentDirMFT+(i*TUPLES_PER_SECTOR), SECTOR_SIZE);
					memcpy(currentDirMFT+(i*TUPLES_PER_SECTOR), buffer, SECTOR_SIZE);
					break;
				}
			}else{
				if (typeV == TYPEVAL_REGULAR && (strcmp(currentBlock[nextRecord].name, name) == 0)){
					memcpy(&currentFileDescriptor,currentBlock+nextRecord,RECORD_SIZE);	
					break;
				}						
			}
		}else{
			return -1;
		}
	}

	return 0;

}

int openDirectoryFromCurrent(char *name){
	int block;
	block = findFromCurrent(name, TYPEVAL_DIRECTORY);
	if (block > 0){
		return openFromCurrent(name, TYPEVAL_DIRECTORY, block);
	}
	return -1;
}
int openFileFromCurrent(char *name){
	int block;
	block = findFromCurrent(name, TYPEVAL_REGULAR);
	if (block > 0){
		return openFromCurrent(name, TYPEVAL_REGULAR, block);		
	}
	return -1;
	
}

/*-------- API --------*/

/*-----------------------------------------------------------------------------

-----------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
Função: Usada para identificar os desenvolvedores do T2FS.
	Essa função copia um string de identificação para o ponteiro indicado por "name".
	Essa cópia não pode exceder o tamanho do buffer, informado pelo parâmetro "size".
	O string deve ser formado apenas por caracteres ASCII (Valores entre 0x20 e 0x7A) e terminado por ‘\0’.
	O string deve conter o nome e número do cartão dos participantes do grupo.

Entra:	name -> buffer onde colocar o string de identificação.
	size -> tamanho do buffer "name" (número máximo de bytes a serem copiados).

Saída:	Se a operação foi realizada com sucesso, a função retorna "0" (zero).
	Em caso de erro, será retornado um valor diferente de zero.
-----------------------------------------------------------------------------*/
int identify2 (char *name, int size){
	static const char idString[] = "Bruno Loureiro - 260725\nEduardo Bassani - 261591\n";
	int nChars = size;
	int length = strlen(idString)+1;

	if (size > length){
		nChars = length;
	}

	memcpy(name, idString, nChars);
	name[nChars] = '\0';

	return 0;
}


/*-----------------------------------------------------------------------------
Função: Criar um novo arquivo.
	O nome desse novo arquivo é aquele informado pelo parâmetro "filename".
	O contador de posição do arquivo (current pointer) deve ser colocado na posição zero.
	Caso já exista um arquivo ou diretório com o mesmo nome, a função deverá retornar um erro de criação.
	A função deve retornar o identificador (handle) do arquivo.
	Esse handle será usado em chamadas posteriores do sistema de arquivo para fins de manipulação do arquivo criado.

Entra:	filename -> path absoluto para o arquivo a ser criado. Todo o "path" deve existir.

Saída:	Se a operação foi realizada com sucesso, a função retorna o handle do arquivo (número positivo).
	Em caso de erro, deve ser retornado um valor negativo.
-----------------------------------------------------------------------------*/
/*
	-Split name into parts (subdirectories)
	-Access most internal directory
	-Check to see if there is not an entry (record) with same name as file
		-If there is, return -1
	-Insert entry on most internal directory
		-If needed, allocate a new block (bitmap)
			-If needed, allocate a new MFT
	-Update father of most internal directory (most internal directory's size has increased by 1 record)
	-Place current file on open file table

*/
//NOTES
//openFileEntry -> must declare t2fs_record as a different variable and assign it
//fix opendirectory,etc
FILE2 create2 (char *filename_o){
	char *entry;
	char *next_entry;
	char *filename;
	int i;
	int len;
	int newBlock;
	openFileEntry newFile;
	t2fs_record newFileRecord;
	t2fs_record records[DIRECTORY_ENTRIES_PER_SECTOR*BLOCK_SIZE];
	BYTE buffer[SECTOR_SIZE];

	filename = (char*)malloc((strlen(filename_o)+1)*sizeof(char));

	memcpy(filename, filename_o, (strlen(filename_o)+1)*sizeof(char));

	if (!initialized)
		initializeSystem();

	if (filename[0] != slash[0])
		return -1;

	entry = strtok(filename, slash);
	entry = strtok(NULL, slash);

	setRootAsCurrentDirectory();

	while (entry != NULL){
		next_entry = strtok(NULL, slash);

		if (next_entry != NULL){
			//this is a directory name, so entry is a directory name
			openDirectoryFromCurrent(entry);

		}else{
			//this is a file name, so entry is a file name
			if ((findFromCurrent(entry, TYPEVAL_REGULAR) != -1) || (findFromCurrent(entry, TYPEVAL_DIRECTORY) != -1)){
				if (DEBUG){
					printf("There's already a file (or directory) with that name!\n");
				}
				return -1;
			}

			for (i = 0; i < MAX_FILES; i++){
				if (!fileIsOpen[i])
					break;
			}
			if (i < MAX_FILES){
				//insert new file;
				newFileRecord.TypeVal = TYPEVAL_REGULAR;
				len = min(strlen(filename_o),MAX_FILE_NAME_SIZE-1);
				memcpy(newFileRecord.name, filename_o, len);
				//might have to fix this
				newFileRecord.name[len] = '\0';
				newFileRecord.blocksFileSize = 0;
				newFileRecord.bytesFileSize = 0;
				newFileRecord.MFTNumber = searchFreeMFTSector();
				newFile.fileDescriptor = newFileRecord;
				
				//insert on currentDir
				newBlock = findFromCurrent(filename_o,TYPEVAL_INVALID);
				if (newBlock != -1){
					//found
					for (i = 0; i < BLOCK_SIZE; i++){
						read_sector(((newBlock*BLOCK_SIZE)+i),buffer);
						memcpy(records+(i*DIRECTORY_ENTRIES_PER_SECTOR), buffer, SECTOR_SIZE);
					}
					for (i = 0; i < DIRECTORY_ENTRIES_PER_SECTOR*BLOCK_SIZE; i++){
						if (records[i].TypeVal == TYPEVAL_INVALID){
							/*records[i].TypeVal == TYPEVAL_REGULAR;
							len = min(strlen(entry), );
							memcpy(records[i].name, entry, len);
							records[i].name[len] = '\0';
							//searchFreeMFTSector();
							records[i].MFTNumber = 
							*/
							memcpy(records+i,&(newFile.fileDescriptor), sizeof(t2fs_record));
							for (i = 0; i < BLOCK_SIZE; i++){
								memcpy(buffer, records+(i*DIRECTORY_ENTRIES_PER_SECTOR), SECTOR_SIZE);
								write_sector(((newBlock*BLOCK_SIZE)+i),buffer);
							}
						}

					}
				}else{
					//need to allocate space for new block
				}

				//Update prev directory to increase current directory's size


				memcpy(openFileTable+i,&newFile,sizeof(openFileEntry));
			}else{
				if (DEBUG){
					printf("Could not create file! There are already the max number of files open.\n");
				}
				return -1;
			}
		}

		entry = next_entry;
	}

}


/*-----------------------------------------------------------------------------
Função:	Apagar um arquivo do disco.
	O nome do arquivo a ser apagado é aquele informado pelo parâmetro "filename".

Entra:	filename -> nome do arquivo a ser apagado.

Saída:	Se a operação foi realizada com sucesso, a função retorna "0" (zero).
	Em caso de erro, será retornado um valor diferente de zero.
-----------------------------------------------------------------------------*/

int delete2 (char *filename){
	if (!initialized)
		initializeSystem();

	// Look for file in directory

	// If not found, return -1

	// Free every block (bitmap)
	// Free the MFT
	// Delete (free) record from directory
	// Update prev directory's record of current directory (size = size - 1 record)

	char *entry;
	char *next_entry;
	char *filename_b;
	int i;
	int len;
	int block;
	int j;
	openFileEntry newFile;
	t2fs_record newFileRecord;
	t2fs_record records[DIRECTORY_ENTRIES_PER_SECTOR*BLOCK_SIZE];
	t2fs_MFT mft;
	BYTE buffer[SECTOR_SIZE];

	filename_b = (char*)malloc((strlen(filename)+1)*sizeof(char));

	memcpy(filename_b, filename, (strlen(filename)+1)*sizeof(char));

	if (!initialized)
		initializeSystem();

	if (filename[0] != '/')
		return -1;

	entry = strtok(filename_b, slash);
	entry = strtok(NULL, slash);

	setRootAsCurrentDirectory();

	while (entry != NULL){
		next_entry = strtok(NULL, slash);

		if (next_entry != NULL){
			//this is a directory name, so entry is a directory name
			openDirectoryFromCurrent(entry);
		}else{
			//this is a file name, so entry is a file name
			block = findFromCurrent(entry, TYPEVAL_REGULAR);
			if (block == -1){
				if (DEBUG){
					printf("There's not a file with that name!\n");
				}
				return -1;
			}

			for (i = 0; i < BLOCK_SIZE; i++){
				read_sector(((block*BLOCK_SIZE)+i),buffer);
				memcpy(records+(i*DIRECTORY_ENTRIES_PER_SECTOR), buffer, SECTOR_SIZE);
			}
			for (i = 0; i < DIRECTORY_ENTRIES_PER_SECTOR*BLOCK_SIZE; i++){
				if (strcmp(records[i].name, entry) == 0){
					memcpy(&(newFileRecord), records+i, sizeof(t2fs_record));
					newFile.fileDescriptor = newFileRecord;
					break;
				}
			}

			// have file descriptor, need to access MFT
			block = newFile.fileDescriptor.MFTNumber;
			mft = readT2FS_MFT_on_sector(FIRST_MFT_SECTOR + (block * SECTORS_PER_MFT_ENTRY));

			// have MFT, need to free blocks

			for (i = 0; i < MFT_ENTRIES_PER_BLOCK; i++){
				if (i == MFT_ENTRIES_PER_BLOCK-1){
					if (mft.tuplas[i].atributeType != 2){
						writeT2FS_MFT_on_sector((FIRST_MFT_SECTOR + (block * SECTORS_PER_MFT_ENTRY)), mft);
						break;
					}
					block = mft.tuplas[i].virtualBlockNumber;
					//write previous
					writeT2FS_MFT_on_sector((FIRST_MFT_SECTOR + (block * SECTORS_PER_MFT_ENTRY)), mft);
					//read new
					mft = readT2FS_MFT_on_sector(FIRST_MFT_SECTOR + (block * SECTORS_PER_MFT_ENTRY));
					i = 0;
				}
				if (mft.tuplas[i].atributeType != 1){
					break;
				}
				for (j = 0; j < mft.tuplas[i].numberOfContiguosBlocks; j++){
					setBitmap2 (((mft.tuplas[i].logicalBlockNumber)+j), 0);
				}
				mft.tuplas[i].atributeType = -1;
			}
			//delete from current directory
			block = findFromCurrent(entry, TYPEVAL_REGULAR);

			for (i = 0; i < BLOCK_SIZE; i++){
				read_sector(((block*BLOCK_SIZE)+i),buffer);
				memcpy(records+(i*DIRECTORY_ENTRIES_PER_SECTOR), buffer, SECTOR_SIZE);
			}
			for (i = 0; i < TUPLES_PER_MFT_ENTRY; i++){
				if (strcmp(records[i].name, entry) == 0){
					records[i].TypeVal = TYPEVAL_INVALID;
					//save
					for (i = 0; i < BLOCK_SIZE; i++){
						memcpy(buffer, records+(i*DIRECTORY_ENTRIES_PER_SECTOR), SECTOR_SIZE);
						write_sector(((block*BLOCK_SIZE)+i), buffer);
					}
					break;
				}
				if (i == TUPLES_PER_MFT_ENTRY-1){
					if (DEBUG){
						printf("Somehow you are trying to delete a file that we already know exists, but it somehow was not found??\n");
					}
					return -1;
				}
			}

			//update record in prev directory to update current directory size

		}
		entry = next_entry;
	}


	return 0;
}

/*-----------------------------------------------------------------------------
Função:	Abre um arquivo existente no disco.
	O nome desse novo arquivo é aquele informado pelo parâmetro "filename".
	Ao abrir um arquivo, o contador de posição do arquivo (current pointer) deve ser colocado na posição zero.
	A função deve retornar o identificador (handle) do arquivo.
	Esse handle será usado em chamadas posteriores do sistema de arquivo para fins de manipulação do arquivo criado.
	Todos os arquivos abertos por esta chamada são abertos em leitura e em escrita.
	O ponto em que a leitura, ou escrita, será realizada é fornecido pelo valor current_pointer (ver função seek2).

Entra:	filename -> nome do arquivo a ser apagado.

Saída:	Se a operação foi realizada com sucesso, a função retorna o handle do arquivo (número positivo)
	Em caso de erro, deve ser retornado um valor negativo
-----------------------------------------------------------------------------*/
FILE2 open2 (char *filename){
	if (!initialized)
		initializeSystem();

	// Pretty much the same thing as create2 except we don't have to update current directory

	return -1;
}


/*-----------------------------------------------------------------------------
Função:	Fecha o arquivo identificado pelo parâmetro "handle".

Entra:	handle -> identificador do arquivo a ser fechado

Saída:	Se a operação foi realizada com sucesso, a função retorna "0" (zero).
	Em caso de erro, será retornado um valor diferente de zero.
-----------------------------------------------------------------------------*/
int close2 (FILE2 handle){
	if (!initialized)
		initializeSystem();

	// Pretty much just set the bool array's [handle] position to false...
	
	return -1;
}

/*-----------------------------------------------------------------------------
Função:	Realiza a leitura de "size" bytes do arquivo identificado por "handle".
	Os bytes lidos são colocados na área apontada por "buffer".
	Após a leitura, o contador de posição (current pointer) deve ser ajustado para o byte seguinte ao último lido.

Entra:	handle -> identificador do arquivo a ser lido
	buffer -> buffer onde colocar os bytes lidos do arquivo
	size -> número de bytes a serem lidos

Saída:	Se a operação foi realizada com sucesso, a função retorna o número de bytes lidos.
	Se o valor retornado for menor do que "size", então o contador de posição atingiu o final do arquivo.
	Em caso de erro, será retornado um valor negativo.
-----------------------------------------------------------------------------*/
int read2 (FILE2 handle, char *buffer, int size){
	if (!initialized)
		initializeSystem();

	// Access file's MFT
	// Access logical block(s) that contains the bytes to be read
	// Copy to buffer
	// only "annoying" thing is when you want to read bytes that are in different blocks but that's really easy

	return -1;
}


/*-----------------------------------------------------------------------------
Função:	Realiza a escrita de "size" bytes no arquivo identificado por "handle".
	Os bytes a serem escritos estão na área apontada por "buffer".
	Após a escrita, o contador de posição (current pointer) deve ser ajustado para o byte seguinte ao último escrito.

Entra:	handle -> identificador do arquivo a ser escrito
	buffer -> buffer de onde pegar os bytes a serem escritos no arquivo
	size -> número de bytes a serem escritos

Saída:	Se a operação foi realizada com sucesso, a função retorna o número de bytes efetivamente escritos.
	Em caso de erro, será retornado um valor negativo.
-----------------------------------------------------------------------------*/
int write2 (FILE2 handle, char *buffer, int size){
	if (!initialized)
		initializeSystem();

	// Access file's MFT
	// Access logical block(s) that contains the bytes to be written
	// "Merge" buffer with block (overwrite bytes that need to be overwriten)
	// If needed, allocate new blocks (bitmap)
		//if new blocks were allocated, update MFT
	// If needed, update record in current directory

	return -1;
}


/*-----------------------------------------------------------------------------
Função:	Função usada para truncar um arquivo.
	Remove do arquivo todos os bytes a partir da posição atual do contador de posição (CP)
	Todos os bytes a partir da posição CP (inclusive) serão removidos do arquivo.
	Após a operação, o arquivo deverá contar com CP bytes e o ponteiro estará no final do arquivo

Entra:	handle -> identificador do arquivo a ser truncado

Saída:	Se a operação foi realizada com sucesso, a função retorna "0" (zero).
	Em caso de erro, será retornado um valor diferente de zero.
-----------------------------------------------------------------------------*/
int truncate2 (FILE2 handle){
	if (!initialized)
		initializeSystem();

	// Access file's MFT
	// Free MFT entries that will no longer be needed (if actually trauncated data)
	// Update record in current directory

	return -1;
}


/*-----------------------------------------------------------------------------
Função:	Reposiciona o contador de posições (current pointer) do arquivo identificado por "handle".
	A nova posição é determinada pelo parâmetro "offset".
	O parâmetro "offset" corresponde ao deslocamento, em bytes, contados a partir do início do arquivo.
	Se o valor de "offset" for "-1", o current_pointer deverá ser posicionado no byte seguinte ao final do arquivo,
		Isso é útil para permitir que novos dados sejam adicionados no final de um arquivo já existente.

Entra:	handle -> identificador do arquivo a ser escrito
	offset -> deslocamento, em bytes, onde posicionar o "current pointer".

Saída:	Se a operação foi realizada com sucesso, a função retorna "0" (zero).
	Em caso de erro, será retornado um valor diferente de zero.
-----------------------------------------------------------------------------*/
int seek2 (FILE2 handle, DWORD offset){
	if (!initialized)
		initializeSystem();
	// Literally just change the value of current pointer ?
	// Maybe check limits
	// Possibly bring buffer to RAM? [optional?]

	return -1;
}


/*-----------------------------------------------------------------------------
Função:	Criar um novo diretório.
	O caminho desse novo diretório é aquele informado pelo parâmetro "pathname".
		O caminho pode ser ser absoluto ou relativo.
	São considerados erros de criação quaisquer situações em que o diretório não possa ser criado.
		Isso inclui a existência de um arquivo ou diretório com o mesmo "pathname".

Entra:	pathname -> caminho do diretório a ser criado

Saída:	Se a operação foi realizada com sucesso, a função retorna "0" (zero).
	Em caso de erro, será retornado um valor diferente de zero.
-----------------------------------------------------------------------------*/
int mkdir2 (char *pathname){
	if (!initialized)
		initializeSystem();

	//actually the same thing as new file except you don't put it on open file table

	return -1;
}


/*-----------------------------------------------------------------------------
Função:	Apagar um subdiretório do disco.
	O caminho do diretório a ser apagado é aquele informado pelo parâmetro "pathname".
	São considerados erros quaisquer situações que impeçam a operação.
		Isso inclui:
			(a) o diretório a ser removido não está vazio;
			(b) "pathname" não existente;
			(c) algum dos componentes do "pathname" não existe (caminho inválido);
			(d) o "pathname" indicado não é um arquivo;

Entra:	pathname -> caminho do diretório a ser criado

Saída:	Se a operação foi realizada com sucesso, a função retorna "0" (zero).
	Em caso de erro, será retornado um valor diferente de zero.
-----------------------------------------------------------------------------*/
int rmdir2 (char *pathname){
	if (!initialized)
		initializeSystem();

	//check if directory has any files
	//if it does, return -1
	//otherwise, remove entry from previous directory and update size of previous directory in the record that's one directory before it

	return -1;
}


/*-----------------------------------------------------------------------------
Função:	Abre um diretório existente no disco.
	O caminho desse diretório é aquele informado pelo parâmetro "pathname".
	Se a operação foi realizada com sucesso, a função:
		(a) deve retornar o identificador (handle) do diretório
		(b) deve posicionar o ponteiro de entradas (current entry) na primeira posição válida do diretório "pathname".
	O handle retornado será usado em chamadas posteriores do sistema de arquivo para fins de manipulação do diretório.

Entra:	pathname -> caminho do diretório a ser aberto

Saída:	Se a operação foi realizada com sucesso, a função retorna o identificador do diretório (handle).
	Em caso de erro, será retornado um valor negativo.
-----------------------------------------------------------------------------*/
DIR2 opendir2 (char *pathname){
	if (!initialized)
		initializeSystem();

	//similar to open file, different structure

	return -1;
}


/*-----------------------------------------------------------------------------
Função:	Realiza a leitura das entradas do diretório identificado por "handle".
	A cada chamada da função é lida a entrada seguinte do diretório representado pelo identificador "handle".
	Algumas das informações dessas entradas devem ser colocadas no parâmetro "dentry".
	Após realizada a leitura de uma entrada, o ponteiro de entradas (current entry) é ajustado para a próxima entrada válida
	São considerados erros:
		(a) término das entradas válidas do diretório identificado por "handle".
		(b) qualquer situação que impeça a realização da operação

Entra:	handle -> identificador do diretório cujas entradas deseja-se ler.
	dentry -> estrutura de dados onde a função coloca as informações da entrada lida.

Saída:	Se a operação foi realizada com sucesso, a função retorna "0" (zero).
	Em caso de erro, será retornado um valor negativo
		Se o diretório chegou ao final, retorna "-END_OF_DIR" (-1)
		Outros erros, será retornado um outro valor negativo
-----------------------------------------------------------------------------*/
#define	END_OF_DIR	1
int readdir2 (DIR2 handle, DIRENT2 *dentry){
	if (!initialized)
		initializeSystem();

	//easier than read from file, just read next record

	return -1;
}


/*-----------------------------------------------------------------------------
Função:	Fecha o diretório identificado pelo parâmetro "handle".

Entra:	handle -> identificador do diretório que se deseja fechar (encerrar a operação).

Saída:	Se a operação foi realizada com sucesso, a função retorna "0" (zero).
	Em caso de erro, será retornado um valor diferente de zero.
-----------------------------------------------------------------------------*/
int closedir2 (DIR2 handle){
	if (!initialized)
		initializeSystem();

	//mark position in array as free

	return -1;
}
